package com.primeirotrampodev.lacofor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LacoforApplicationTests {

	@Test
	void contextLoads() {
	}

}
